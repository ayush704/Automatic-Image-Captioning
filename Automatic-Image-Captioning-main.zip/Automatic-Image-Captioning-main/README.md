# Automatic-Image-Captioning
A model that takes a photo as input and gives description of the objects/scenery in the picture.
